#![allow(non_camel_case_types)]
#![allow(non_upper_case_globals)]
#![allow(dead_code)]
#![allow(clippy::unnecessary_cast)]

include!(concat!(env!("OUT_DIR"), "/micropython.rs"));
