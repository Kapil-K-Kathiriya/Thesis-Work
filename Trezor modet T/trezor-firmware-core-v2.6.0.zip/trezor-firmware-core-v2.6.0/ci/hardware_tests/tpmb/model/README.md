# 3D print model for tpmb

This is pretty easy to print. First open ```base.scad``` with OpenSCAD and
export your ```.stl``` file with it.

Open it with your slider, we are using
Original Prusa i3 MK3 to print our models. 0.15mm quality setting with standard
PLA works fine for us.
