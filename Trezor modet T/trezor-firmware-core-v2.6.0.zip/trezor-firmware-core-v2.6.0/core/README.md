# Trezor Core

Firmware currently running on Model T.

See `docs/core` for more info.
