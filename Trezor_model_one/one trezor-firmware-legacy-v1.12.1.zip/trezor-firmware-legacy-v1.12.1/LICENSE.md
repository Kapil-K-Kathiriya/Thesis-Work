# License

This is a monorepo and different parts of monorepo are licensed
under different licenses:

* `common` - [LGPLv3](common/COPYING)
* `core` - [GPLv3](core/COPYING)
* `crypto` - mostly<sup>1</sup> [MIT](crypto/LICENSE)
* `legacy` - [LGPLv3](legacy/COPYING)
* `python` - [LGPLv3](python/COPYING)
* `storage` - [GPLv3](storage/COPYING)
* all other files - [GPLv3](COPYING)

<sup>1</sup> some files have individual licensing,
check the file headers for more information
