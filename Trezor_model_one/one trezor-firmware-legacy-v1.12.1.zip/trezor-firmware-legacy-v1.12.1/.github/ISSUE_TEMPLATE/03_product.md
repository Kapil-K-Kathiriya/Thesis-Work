---
name: Product feature
about: New product feature ready for development.
title: ''
labels: product
assignees: ''

---

**Design:** [Figma](TODO)

**Spec:** [Notion](TODO)
