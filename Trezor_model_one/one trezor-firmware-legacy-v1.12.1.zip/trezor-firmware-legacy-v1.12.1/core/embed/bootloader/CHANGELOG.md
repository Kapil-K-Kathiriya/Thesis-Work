# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).


## 2.0.4 [May 2022]

### Security
- Intentionally skipped this version due to fake devices

## 2.0.3 [March 2019]

### Security
- Enable MPU
- Introduce delays to USB stack

## 2.0.2 [December 2018]

### Added
- Support for a new display driver

## 2.0.1 [February 2018]

### Added
- First public release
