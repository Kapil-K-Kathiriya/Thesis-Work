#include "common.h"

void loader_uncompress_r(int32_t y_offset, uint16_t fg_color, uint16_t bg_color,
                         uint16_t icon_color, int32_t progress,
                         int32_t indeterminate, const uint8_t* icon_data,
                         uint32_t icon_data_size);
